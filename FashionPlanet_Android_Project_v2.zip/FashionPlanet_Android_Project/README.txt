FASHION PLANET ANDROID PROJECT
Version 1.0 UI prototype.

Important: This package is an Android Studio source project, not an APK.
The current environment does not contain the Android SDK/Gradle build toolchain needed to
compile and sign an installable APK.

Included:
- Fashion Planet branding/logo
- Dashboard
- Billing / GST invoice UI
- Manual invoice number
- Customer Khata UI
- Stock UI
- Reports
- Phone/tablet responsive web UI

Next production work:
- Cloud database and secure sync between phone/tablet
- Real customer/khata/stock database
- Real GST calculations and invoice persistence
- PDF/print/WhatsApp integration
- Authentication/device pairing
- Offline sync conflict handling
- Signed release APK/AAB
